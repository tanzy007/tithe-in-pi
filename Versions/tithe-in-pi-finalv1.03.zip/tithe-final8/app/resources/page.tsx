"use client"

import { Navigation } from "@/components/navigation"
import { ArrowLeft, FileText, Printer, ChevronRight, Users, BookOpen, Mail } from "lucide-react"
import Link from "next/link"

const RESOURCES = {
  churchKit: "https://drive.google.com/file/d/120iOC-sNJ0qbdEYGkhkY20ks46VBuohy/view?usp=sharing",
  churchFlyer: "", // add when uploaded
  pioneerLetter: "https://drive.google.com/file/d/1-Igam_mO0NUFQ37p36Cx2DB-9vI93pKn/view?usp=sharing",
  congregantHandout: "https://drive.google.com/file/d/16aq48RXEGqjsm1r3NGVqhORsLbHK1hMO/view?usp=sharing",
}

export default function ResourcesPage() {
  return (
    <>
      <div className="min-h-screen bg-background pb-20">
        <main className="container mx-auto px-4 py-6 max-w-lg">
          <div className="mb-6">
            <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
            <h1 className="text-2xl font-bold mb-2">Church Resources</h1>
            <p className="text-muted-foreground text-sm">Everything your church needs to get started with Pi giving</p>
          </div>

          {/* For Churches & Pioneers */}
          <div className="mb-6">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">For Churches & Pioneers</h2>
            <div className="space-y-3">

              <a href={RESOURCES.churchKit} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 hover:border-primary/50 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <FileText className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-sm">Church Onboarding Guide</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Full PDF — 3 steps, trust levels, FAQs</div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </a>

              {RESOURCES.churchFlyer ? (
                <a href={RESOURCES.churchFlyer} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 hover:border-primary/50 transition-colors">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Printer className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-sm">Printable Church Flyer</div>
                    <div className="text-xs text-muted-foreground mt-0.5">One-page handout for pastor meetups & events</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </a>
              ) : (
                <div className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 opacity-40">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Printer className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-sm">Printable Church Flyer</div>
                    <div className="text-xs text-muted-foreground mt-0.5">Coming soon</div>
                  </div>
                </div>
              )}

              <a href={RESOURCES.pioneerLetter} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 hover:border-primary/50 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-sm">Pioneer → Church Letter</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Print & hand to your priest or pastor</div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </a>

            </div>
          </div>

          {/* For Congregants */}
          <div className="mb-6">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">For Congregants</h2>
            <div className="space-y-3">

              <a href={RESOURCES.congregantHandout} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 hover:border-green-500/30 transition-colors">
                <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center flex-shrink-0">
                  <Users className="w-5 h-5 text-green-600" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-sm">Congregant Handout</div>
                  <div className="text-xs text-muted-foreground mt-0.5">How to start mining Pi & donate to your church</div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </a>

            </div>

            <div className="mt-3 bg-muted/20 border border-border rounded-xl p-3">
              <p className="text-xs text-muted-foreground leading-relaxed">
                💡 <span className="font-semibold text-foreground">Tip for Pioneers:</span> Fill in your Pi invitation code on the congregant handout before printing. Every sign-up using your code boosts your mining rate.
              </p>
            </div>
          </div>

          {/* How It Works */}
          <div className="mb-6">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">How It Works</h2>
            <div className="space-y-3">
              {[
                { num: "1", title: "Register your church", desc: "Add your church name, location and contact details. Takes 2 minutes.", color: "bg-amber-50 text-amber-700" },
                { num: "2", title: "Add your Pi wallet", desc: "Paste your Pi wallet address so donors can give directly to you.", color: "bg-blue-50 text-blue-700" },
                { num: "3", title: "Submit verification proof", desc: "Post your wallet address publicly so we can independently confirm it's yours.", color: "bg-green-50 text-green-700" },
              ].map((step) => (
                <div key={step.num} className="flex items-start gap-4 bg-card border border-border rounded-xl p-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold ${step.color}`}>
                    {step.num}
                  </div>
                  <div>
                    <div className="font-semibold text-sm">{step.title}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{step.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Trust levels */}
          <div className="mb-6">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Trust Level Badges</h2>
            <div className="bg-card border border-border rounded-xl divide-y divide-border">
              {[
                { label: "Listed", desc: "Basic info registered", color: "bg-gray-100 text-gray-600" },
                { label: "Pi-Ready", desc: "Wallet added, not yet verified", color: "bg-blue-50 text-blue-700" },
                { label: "Pending", desc: "Proof submitted, under review", color: "bg-amber-50 text-amber-700" },
                { label: "Verified", desc: "Independently confirmed ✓", color: "bg-green-50 text-green-700" },
                { label: "Highly Verified", desc: "Charity number or KYB confirmed", color: "bg-purple-50 text-purple-700" },
              ].map((level) => (
                <div key={level.label} className="flex items-center gap-3 px-4 py-3">
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${level.color} whitespace-nowrap`}>{level.label}</span>
                  <span className="text-sm text-muted-foreground">{level.desc}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Contact */}
          <div className="bg-muted/30 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-2">
              <Mail className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-semibold">Need help?</span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Contact us at{" "}
              <a href="mailto:hello@tithe.pi" className="text-primary hover:underline">hello@tithe.pi</a>
            </p>
          </div>

          {/* CTA */}
          <div className="mt-6">
            <Link
              href="/register"
              className="flex items-center justify-center gap-2 w-full bg-primary text-primary-foreground rounded-xl py-3.5 font-semibold text-sm hover:opacity-90 transition-opacity"
            >
              Register Your Church Now
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

        </main>
      </div>
      <Navigation />
    </>
  )
}
