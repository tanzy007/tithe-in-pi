export function AuthLoadingScreen() {
  return null
}
