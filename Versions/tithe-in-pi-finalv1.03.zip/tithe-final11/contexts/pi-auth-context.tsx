"use client";
import React, { createContext, useContext, type ReactNode } from "react";

interface PiAuthContextType {
  isAuthenticated: boolean;
  piAccessToken: string | null;
}

const PiAuthContext = createContext<PiAuthContextType>({ isAuthenticated: true, piAccessToken: null });

export function PiAuthProvider({ children }: { children: ReactNode }) {
  return <PiAuthContext.Provider value={{ isAuthenticated: true, piAccessToken: null }}>{children}</PiAuthContext.Provider>;
}

export function usePiAuth() {
  return useContext(PiAuthContext);
}
