"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Navigation } from "@/components/navigation"
import { getSupabase } from "@/lib/supabase"
import type { Church, TrustLevel } from "@/lib/supabase"
import { TRUST_LEVEL_LABELS, TRUST_LEVEL_DESCRIPTIONS } from "@/lib/supabase"
import { ArrowLeft, Check, Clock, Shield, ShieldCheck, Star, Wallet, FileText } from "lucide-react"
import Link from "next/link"

const TRUST_COLORS: Record<TrustLevel, string> = {
  listed: "bg-gray-100 text-gray-600 border-gray-200",
  pi_ready: "bg-blue-50 text-blue-700 border-blue-200",
  pending: "bg-amber-50 text-amber-700 border-amber-200",
  verified: "bg-green-50 text-green-700 border-green-200",
  highly_verified: "bg-purple-50 text-purple-700 border-purple-200",
}

export default function OnboardPage() {
  const searchParams = useSearchParams()
  const churchIdFromUrl = searchParams.get("id")

  const [churches, setChurches] = useState<Church[]>([])
  const [selectedChurch, setSelectedChurch] = useState("")
  const [walletAddress, setWalletAddress] = useState("")
  const [leaderName, setLeaderName] = useState("")
  const [leaderTitle, setLeaderTitle] = useState("")
  const [charityNumber, setCharityNumber] = useState("")
  const [physicalAddress, setPhysicalAddress] = useState("")
  const [walletConfirmChecked, setWalletConfirmChecked] = useState(false)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState("")
  const [error, setError] = useState("")

  useEffect(() => { loadChurches() }, [])

  const loadChurches = async () => {
    const supabase = getSupabase()
    const { data } = await supabase.from("churches").select("*").order("created_at", { ascending: false })
    if (data) {
      setChurches(data)
      const churchToSelect = churchIdFromUrl || (data.length > 0 ? data[0].id : "")
      if (churchToSelect) {
        const church = data.find((c) => c.id === churchToSelect) || data[0]
        setSelectedChurch(church.id)
        prefillChurch(church)
      }
    }
  }

  const prefillChurch = (church: Church) => {
    setWalletAddress(church.wallet_address || "")
    setLeaderName(church.leader_name || "")
    setLeaderTitle(church.leader_title || "")
    setCharityNumber(church.charity_number || "")
    setPhysicalAddress(church.physical_address || "")
  }

  const handleChurchChange = (churchId: string) => {
    setSelectedChurch(churchId)
    const church = churches.find((c) => c.id === churchId)
    if (church) prefillChurch(church)
  }

  const selectedChurchData = churches.find((c) => c.id === selectedChurch)
  const currentTrustLevel: TrustLevel = (selectedChurchData?.trust_level as TrustLevel) || "listed"

  const trustStep = { listed: 0, pi_ready: 1, pending: 2, verified: 3, highly_verified: 4 }[currentTrustLevel]

  const updateChurch = async (updates: Partial<Church>) => {
    if (!selectedChurch) return false
    setLoading(true)
    setError("")
    try {
      const supabase = getSupabase()
      const { error: updateError } = await supabase
        .from("churches")
        .update({ ...updates, last_updated: new Date().toISOString() })
        .eq("id", selectedChurch)
      if (updateError) throw updateError
      await loadChurches()
      return true
    } catch (err) {
      setError(err instanceof Error ? err.message : "Update failed. Check your Supabase RLS policies.")
      return false
    } finally {
      setLoading(false)
    }
  }

  const handleSaveWallet = async () => {
    if (!walletAddress || !walletConfirmChecked) return
    const ok = await updateChurch({ wallet_address: walletAddress, trust_level: "pi_ready", wallet_confirmed: false })
    if (ok) { setSuccess("Wallet saved! Your church is now Pi-Ready."); setTimeout(() => setSuccess(""), 3000) }
  }

  const handleSubmitProof = async () => {
    const ok = await updateChurch({ trust_level: "pending", verification_method: "public_proof" })
    if (ok) { setSuccess("Proof submitted! Your church is now pending independent review."); setTimeout(() => setSuccess(""), 4000) }
  }

  const handleSaveAdvanced = async () => {
    const ok = await updateChurch({
      leader_name: leaderName || null,
      leader_title: leaderTitle || null,
      charity_number: charityNumber || null,
      physical_address: physicalAddress || null,
    })
    if (ok) { setSuccess("Additional credentials saved and sent for review."); setTimeout(() => setSuccess(""), 3000) }
  }

  return (
    <>
      <div className="min-h-screen bg-background pb-20">
        <main className="container mx-auto px-4 py-6 max-w-lg">
          <div className="mb-6">
            <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4">
              <ArrowLeft className="w-4 h-4" />Back to Home
            </Link>
            <h1 className="text-2xl font-bold mb-2">Church Onboarding</h1>
            <p className="text-muted-foreground text-sm">Build donor trust step by step</p>
          </div>

          {churches.length > 0 && (
            <div className="mb-6">
              <Label htmlFor="church-select">Select Your Church</Label>
              <select id="church-select" value={selectedChurch} onChange={(e) => handleChurchChange(e.target.value)}
                className="w-full mt-1.5 h-10 rounded-lg border border-input bg-background px-3 py-2 text-sm">
                {churches.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          )}

          {churches.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No churches registered yet</p>
              <Link href="/register"><Button>Register Your Church</Button></Link>
            </div>
          )}

          {selectedChurchData && (
            <>
              {/* Trust Badge */}
              <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm font-medium mb-2 ${TRUST_COLORS[currentTrustLevel]}`}>
                {currentTrustLevel === "listed" && <FileText className="w-3.5 h-3.5" />}
                {currentTrustLevel === "pi_ready" && <Wallet className="w-3.5 h-3.5" />}
                {currentTrustLevel === "pending" && <Clock className="w-3.5 h-3.5" />}
                {currentTrustLevel === "verified" && <ShieldCheck className="w-3.5 h-3.5" />}
                {currentTrustLevel === "highly_verified" && <Star className="w-3.5 h-3.5" />}
                {TRUST_LEVEL_LABELS[currentTrustLevel]}
              </div>
              <p className="text-xs text-muted-foreground mb-6">{TRUST_LEVEL_DESCRIPTIONS[currentTrustLevel]}</p>

              {/* Progress bar */}
              <div className="flex items-center gap-1 mb-8">
                {[0,1,2,3,4].map((i) => (
                  <div key={i} className="flex items-center flex-1 last:flex-none">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0
                      ${trustStep > i ? "bg-green-500 text-white" : trustStep === i ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                      {trustStep > i ? <Check className="w-3 h-3" /> : i + 1}
                    </div>
                    {i < 4 && <div className={`h-0.5 flex-1 mx-1 ${trustStep > i ? "bg-green-500" : "bg-muted"}`} />}
                  </div>
                ))}
              </div>

              <div className="space-y-4">
                {/* Step 1: Wallet */}
                <div className={`rounded-xl p-5 border ${currentTrustLevel === "listed" ? "border-primary bg-card shadow-sm" : "border-border bg-card/50"}`}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-semibold
                      ${trustStep >= 1 ? "bg-green-500 text-white" : currentTrustLevel === "listed" ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                      {trustStep >= 1 ? <Check className="w-4 h-4" /> : "1"}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold">Add Pi Wallet</h3>
                      <p className="text-xs text-muted-foreground">Required to receive donations</p>
                    </div>
                    {trustStep >= 1 && <span className="text-xs text-green-600 font-medium">Done</span>}
                  </div>
                  {(currentTrustLevel === "listed" || currentTrustLevel === "pi_ready") && (
                    <div className="space-y-3 mt-3">
                      <Input value={walletAddress} onChange={(e) => setWalletAddress(e.target.value)}
                        placeholder="Your Pi wallet address" className="font-mono text-sm" />
                      <label className="flex items-start gap-2 text-sm cursor-pointer">
                        <input type="checkbox" checked={walletConfirmChecked} onChange={(e) => setWalletConfirmChecked(e.target.checked)} className="mt-0.5" />
                        <span className="text-muted-foreground">This wallet is controlled by our ministry and we have access to it.</span>
                      </label>
                      <Button onClick={handleSaveWallet} disabled={loading || !walletAddress || !walletConfirmChecked} className="w-full" size="sm">
                        Save Wallet Address
                      </Button>
                    </div>
                  )}
                  {trustStep >= 1 && selectedChurchData.wallet_address && (
                    <div className="mt-3 text-xs text-muted-foreground font-mono truncate bg-muted/30 rounded px-3 py-2">
                      {selectedChurchData.wallet_address}
                    </div>
                  )}
                </div>

                {/* Step 2: Submit Proof */}
                <div className={`rounded-xl p-5 border ${currentTrustLevel === "pi_ready" ? "border-primary bg-card shadow-sm" : "border-border bg-card/50"}`}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-semibold
                      ${trustStep >= 2 ? "bg-green-500 text-white" : currentTrustLevel === "pi_ready" ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                      {trustStep >= 2 ? <Check className="w-4 h-4" /> : "2"}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold">Submit Verification Proof</h3>
                      <p className="text-xs text-muted-foreground">Links your wallet to your ministry publicly</p>
                    </div>
                    {currentTrustLevel === "pending" && <span className="text-xs text-amber-600 font-medium">Under Review</span>}
                    {trustStep >= 3 && <span className="text-xs text-green-600 font-medium">Verified</span>}
                  </div>
                  {currentTrustLevel === "pi_ready" && (
                    <div className="mt-3 space-y-3">
                      <div className="bg-muted/40 rounded-lg p-3 text-sm text-muted-foreground">
                        <p className="font-medium text-foreground mb-1">How to verify your wallet:</p>
                        <p>Post your Pi wallet address on your ministry's official website or public social media (website footer, about page, Facebook bio, etc.), then click Submit below.</p>
                      </div>
                      <Button onClick={handleSubmitProof} disabled={loading} className="w-full" size="sm">
                        <Shield className="w-4 h-4 mr-2" />Submit Verification Proof
                      </Button>
                      <p className="text-xs text-muted-foreground text-center">You'll show as <strong>Pending</strong> until our team independently confirms. This may take a few days.</p>
                    </div>
                  )}
                  {currentTrustLevel === "pending" && (
                    <div className="mt-3 bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-700">
                      <Clock className="w-4 h-4 inline mr-1.5" />Your proof is being reviewed. You appear as Pending in the directory. We'll update your status after independent confirmation.
                    </div>
                  )}
                  {trustStep >= 3 && (
                    <div className="mt-3 bg-green-50 border border-green-200 rounded-lg p-3 text-sm text-green-700">
                      <ShieldCheck className="w-4 h-4 inline mr-1.5" />Independently verified ✓
                    </div>
                  )}
                </div>

                {/* Step 3: Advanced (optional) */}
                <div className={`rounded-xl p-5 border ${currentTrustLevel === "verified" ? "border-primary bg-card shadow-sm" : "border-border bg-card/50"}`}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-semibold
                      ${currentTrustLevel === "highly_verified" ? "bg-purple-500 text-white" : "bg-muted text-muted-foreground"}`}>
                      {currentTrustLevel === "highly_verified" ? <Star className="w-4 h-4" /> : "3"}
                    </div>
                    <div>
                      <h3 className="font-semibold">Optional: Advanced Credentials</h3>
                      <p className="text-xs text-muted-foreground">For Highly Verified status</p>
                    </div>
                  </div>
                  <div className="space-y-3 mt-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label htmlFor="leader_name" className="text-xs">Leader Name</Label>
                        <Input id="leader_name" value={leaderName} onChange={(e) => setLeaderName(e.target.value)} placeholder="Pastor Jane Smith" className="mt-1 text-sm" />
                      </div>
                      <div>
                        <Label htmlFor="leader_title" className="text-xs">Title</Label>
                        <Input id="leader_title" value={leaderTitle} onChange={(e) => setLeaderTitle(e.target.value)} placeholder="Senior Pastor" className="mt-1 text-sm" />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="charity_number" className="text-xs">Charity / Registration Number</Label>
                      <Input id="charity_number" value={charityNumber} onChange={(e) => setCharityNumber(e.target.value)} placeholder="e.g. 1234567" className="mt-1 text-sm" />
                    </div>
                    <div>
                      <Label htmlFor="physical_address" className="text-xs">Physical Address</Label>
                      <Input id="physical_address" value={physicalAddress} onChange={(e) => setPhysicalAddress(e.target.value)} placeholder="123 Church St, City, State" className="mt-1 text-sm" />
                    </div>
                    <Button onClick={handleSaveAdvanced} disabled={loading || (!charityNumber && !physicalAddress && !leaderName)} variant="outline" className="w-full" size="sm">
                      Save Additional Credentials
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">Our team will review these for Highly Verified status</p>
                  </div>
                </div>
              </div>

              {success && <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700 text-center">{success}</div>}
              {error && <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-sm text-destructive text-center">{error}</div>}

              <div className="mt-6 p-4 bg-muted/30 rounded-xl text-xs text-muted-foreground text-center leading-relaxed">
                Donations go directly to the ministry's Pi wallet. Tithe in Pi does not hold or control funds. Please donate responsibly.
              </div>
            </>
          )}
        </main>
      </div>
      <Navigation />
    </>
  )
}
