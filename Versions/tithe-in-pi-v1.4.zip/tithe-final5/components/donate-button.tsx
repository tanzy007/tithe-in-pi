"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Coins, Copy, Check } from "lucide-react"

export function DonateButton({
  walletAddress,
  churchName,
}: {
  walletAddress: string
  churchName: string
}) {
  const [copied, setCopied] = useState(false)
  const [showManual, setShowManual] = useState(false)

  const handleDonate = () => {
    // Use Pi SDK payment flow if available
    if (typeof window !== "undefined" && window.Pi) {
      const payment = {
        amount: 0, // User will set amount in Pi wallet
        memo: `Donation to ${churchName}`,
        metadata: {
          churchName,
          walletAddress,
          type: "tithe_donation",
        },
      }

      const callbacks = {
        onReadyForServerApproval: (paymentId: string) => {
          // For a simple directory we don't run a server approval
          // so we just show the wallet address for manual transfer
          console.log("Payment ready:", paymentId)
          setShowManual(true)
        },
        onReadyForServerCompletion: (paymentId: string, txid: string) => {
          console.log("Payment complete:", paymentId, txid)
        },
        onCancel: (paymentId: string) => {
          console.log("Payment cancelled:", paymentId)
        },
        onError: (error: Error) => {
          console.error("Payment error:", error)
          setShowManual(true)
        },
      }

      try {
        window.Pi.createPayment(payment, callbacks)
      } catch {
        // Pi SDK not available or createPayment not supported — fall back
        setShowManual(true)
      }
    } else {
      // Not inside Pi Browser — show manual instructions
      setShowManual(true)
    }
  }

  const copyAddress = () => {
    navigator.clipboard.writeText(walletAddress).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <div className="bg-card rounded-2xl p-6 border border-border">
      <div className="text-center mb-4">
        <h2 className="font-semibold text-lg mb-2">Support This Ministry</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Donate securely through your Pi Wallet
        </p>
      </div>

      <Button onClick={handleDonate} className="w-full h-14 text-base gap-2" size="lg">
        <Coins className="w-5 h-5" />
        Donate in Pi
      </Button>

      {showManual && (
        <div className="mt-4 p-4 bg-muted/40 rounded-xl border border-border">
          <p className="text-sm font-semibold mb-2 text-center">Send Pi directly to this wallet</p>
          <p className="text-xs text-muted-foreground text-center mb-3 leading-relaxed">
            Open your Pi wallet app, tap Send, and paste the address below
          </p>
          <div className="flex items-center gap-2 bg-background rounded-lg p-2 border border-border">
            <code className="text-xs flex-1 truncate text-muted-foreground">{walletAddress}</code>
            <button
              onClick={copyAddress}
              className="flex-shrink-0 p-1.5 rounded-md hover:bg-muted transition-colors"
            >
              {copied
                ? <Check className="w-4 h-4 text-green-500" />
                : <Copy className="w-4 h-4 text-muted-foreground" />
              }
            </button>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-2">
            Use memo: <span className="font-medium">Donation to {churchName}</span>
          </p>
        </div>
      )}

      {!showManual && (
        <p className="text-xs text-muted-foreground text-center mt-3 leading-relaxed">
          You control the donation amount. Funds go directly to the church wallet.
        </p>
      )}
    </div>
  )
}
