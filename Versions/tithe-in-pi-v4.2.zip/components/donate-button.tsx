"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Coins, Copy, Check } from "lucide-react"

const PRESET_AMOUNTS = [1, 3, 5, 10]

export function DonateButton({
  walletAddress,
  churchName,
}: {
  walletAddress: string
  churchName: string
}) {
  const [open, setOpen] = useState(false)
  const [amount, setAmount] = useState("")
  const [copied, setCopied] = useState(false)

  const parsedAmount = parseFloat(amount)
  const isValidAmount = !isNaN(parsedAmount) && parsedAmount > 0

  function handleOpen() {
    setAmount("")
    setCopied(false)
    setOpen(true)
  }

  function handleClose() {
    setOpen(false)
    setTimeout(() => {
      setAmount("")
      setCopied(false)
    }, 300)
  }

  function copyAddress() {
    navigator.clipboard.writeText(walletAddress).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2500)
    })
  }

  return (
    <>
      <div className="bg-card rounded-2xl p-6 border border-border">
        <div className="text-center mb-4">
          <h2 className="font-semibold text-lg mb-1">Support This Ministry</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Donate directly from your Pi Wallet — no fees, no middlemen
          </p>
        </div>

        <Button onClick={handleOpen} className="w-full h-14 text-base gap-2" size="lg">
          <Coins className="w-5 h-5" />
          Donate in Pi
        </Button>

        <p className="text-xs text-muted-foreground text-center mt-3 leading-relaxed">
          100% goes directly to the church wallet. You control the amount.
        </p>
      </div>

      <Dialog open={open} onOpenChange={(v) => { if (!v) handleClose() }}>
        <DialogContent className="max-w-sm rounded-2xl p-0 overflow-hidden">
          <div className="p-6">
            <DialogHeader className="mb-5 text-left">
              <DialogTitle className="text-lg">Donate to {churchName}</DialogTitle>
              <DialogDescription className="text-sm leading-relaxed">
                Choose an amount, copy the wallet address, and send directly from your Pi Wallet.
              </DialogDescription>
            </DialogHeader>

            {/* Preset amounts */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              {PRESET_AMOUNTS.map((p) => (
                <button
                  key={p}
                  onClick={() => setAmount(String(p))}
                  className={`rounded-xl py-2.5 text-sm font-semibold border transition-colors ${
                    amount === String(p)
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-muted/40 text-foreground border-border hover:bg-muted"
                  }`}
                >
                  {p} π
                </button>
              ))}
            </div>

            {/* Custom amount */}
            <div className="mb-5">
              <Label htmlFor="donate-amount" className="text-xs text-muted-foreground mb-1.5 block">
                Or enter a custom amount
              </Label>
              <div className="relative">
                <Input
                  id="donate-amount"
                  type="number"
                  min="0.01"
                  step="0.01"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="pr-8 text-base"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm font-medium">π</span>
              </div>
            </div>

            {/* Amount confirmation */}
            {isValidAmount && (
              <div className="bg-muted/40 rounded-xl p-3 mb-4 border border-border">
                <p className="text-xs text-muted-foreground mb-1">You are sending</p>
                <p className="text-lg font-bold">{parsedAmount} π <span className="text-sm font-normal text-muted-foreground">to {churchName}</span></p>
              </div>
            )}

            {/* Wallet address */}
            <div className="bg-muted/40 rounded-xl p-3 border border-border mb-5">
              <p className="text-xs text-muted-foreground mb-2">Church Pi Wallet Address</p>
              <p className="text-xs font-mono break-all text-foreground mb-3 leading-relaxed select-all">{walletAddress}</p>
              <button
                onClick={copyAddress}
                className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                  copied
                    ? "bg-green-100 text-green-700 border border-green-200"
                    : "bg-primary text-primary-foreground hover:bg-primary/90"
                }`}
              >
                {copied
                  ? <><Check className="w-4 h-4" /> Copied!</>
                  : <><Copy className="w-4 h-4" /> Copy Wallet Address</>
                }
              </button>
            </div>

            {/* Steps */}
            <div className="space-y-2 mb-5">
              {[
                "Copy the wallet address above",
                "Open your Pi Wallet app",
                `Send ${isValidAmount ? parsedAmount + " π" : "your chosen amount"} to the copied address`,
                `Add memo: Donation to ${churchName}`,
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {i + 1}
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{step}</p>
                </div>
              ))}
            </div>

            {/* Direct giving note */}
            <div className="bg-green-50 border border-green-100 rounded-xl p-3 mb-4">
              <p className="text-xs text-green-700 text-center leading-relaxed font-medium">
                ✓ Donations go directly to the church wallet — no fees, no middlemen, 100% to the ministry
              </p>
            </div>

            <Button variant="outline" className="w-full" onClick={handleClose}>
              Done
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
