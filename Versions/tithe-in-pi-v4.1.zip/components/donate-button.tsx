"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Coins, Copy, Check, CircleCheck, Loader2, X } from "lucide-react"
import { usePiAuth } from "@/contexts/pi-auth-context"

type DonateStep = "input" | "processing" | "success" | "manual"

const PRESET_AMOUNTS = [1, 3, 5, 10]

export function DonateButton({
  walletAddress,
  churchName,
}: {
  walletAddress: string
  churchName: string
}) {
  const { piAccessToken } = usePiAuth()
  const [open, setOpen] = useState(false)
  const [amount, setAmount] = useState("")
  const [step, setStep] = useState<DonateStep>("input")
  const [copied, setCopied] = useState(false)
  const [txId, setTxId] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const parsedAmount = parseFloat(amount)
  const isValidAmount = !isNaN(parsedAmount) && parsedAmount > 0

  function resetDialog() {
    setStep("input")
    setAmount("")
    setError(null)
    setTxId(null)
    setCopied(false)
  }

  function handleOpen() {
    resetDialog()
    setOpen(true)
  }

  function handleClose() {
    setOpen(false)
    setTimeout(resetDialog, 300)
  }

  async function handleDonate() {
    if (!isValidAmount) return
    setError(null)

    const memo = `Donation to ${churchName}`

    if (typeof window !== "undefined" && window.Pi && typeof window.Pi.createPayment === "function") {
      setStep("processing")

      const payment = {
        amount: parsedAmount,
        memo,
        metadata: {
          churchName,
          walletAddress,
          type: "tithe_donation",
        },
      }

      const callbacks = {
        onReadyForServerApproval: async (paymentId: string) => {
          try {
            // Approve the payment server-side
            await fetch(`https://backend.appstudio-u7cm9zhmha0ruwv8.piappengine.com/proxy/v2/payments/${paymentId}/approve`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                ...(piAccessToken ? { "Authorization": `Bearer ${piAccessToken}` } : {}),
              },
            })
          } catch {
            // If approval fails fall back to manual
            setStep("manual")
          }
        },
        onReadyForServerCompletion: async (paymentId: string, txid: string) => {
          try {
            // Complete the payment server-side
            await fetch(`https://backend.appstudio-u7cm9zhmha0ruwv8.piappengine.com/proxy/v2/payments/${paymentId}/complete`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                ...(piAccessToken ? { "Authorization": `Bearer ${piAccessToken}` } : {}),
              },
              body: JSON.stringify({ txid }),
            })
            setTxId(txid)
            setStep("success")
          } catch {
            // Payment went through even if completion call fails
            setTxId(txid)
            setStep("success")
          }
        },
        onCancel: (_paymentId: string) => {
          setStep("input")
        },
        onError: (_err: Error) => {
          setStep("manual")
        },
      }

      try {
        window.Pi.createPayment(payment, callbacks)
      } catch {
        setStep("manual")
      }
    } else {
      // Outside Pi Browser — show manual send instructions
      setStep("manual")
    }
  }

  function copyAddress() {
    navigator.clipboard.writeText(walletAddress).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <>
      <div className="bg-card rounded-2xl p-6 border border-border">
        <div className="text-center mb-4">
          <h2 className="font-semibold text-lg mb-1">Support This Ministry</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Donate securely through your Pi Wallet
          </p>
        </div>

        <Button onClick={handleOpen} className="w-full h-14 text-base gap-2" size="lg">
          <Coins className="w-5 h-5" />
          Donate in Pi
        </Button>

        <p className="text-xs text-muted-foreground text-center mt-3 leading-relaxed">
          You control the amount. Funds go directly to the church wallet.
        </p>
      </div>

      <Dialog open={open} onOpenChange={(v) => { if (!v) handleClose() }}>
        <DialogContent className="max-w-sm rounded-2xl p-0 overflow-hidden">

          {/* ── Input step ── */}
          {step === "input" && (
            <div className="p-6">
              <DialogHeader className="mb-5 text-left">
                <DialogTitle className="text-lg">Donate to {churchName}</DialogTitle>
                <DialogDescription className="text-sm leading-relaxed">
                  Choose an amount to donate in Pi. The donation goes directly to the church wallet.
                </DialogDescription>
              </DialogHeader>

              {/* Preset amounts */}
              <div className="grid grid-cols-4 gap-2 mb-4">
                {PRESET_AMOUNTS.map((p) => (
                  <button
                    key={p}
                    onClick={() => setAmount(String(p))}
                    className={`rounded-xl py-2.5 text-sm font-semibold border transition-colors ${
                      amount === String(p)
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-muted/40 text-foreground border-border hover:bg-muted"
                    }`}
                  >
                    {p} π
                  </button>
                ))}
              </div>

              {/* Custom amount */}
              <div className="mb-5">
                <Label htmlFor="donate-amount" className="text-xs text-muted-foreground mb-1.5 block">
                  Or enter a custom amount
                </Label>
                <div className="relative">
                  <Input
                    id="donate-amount"
                    type="number"
                    min="0.01"
                    step="0.01"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="pr-8 text-base"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm font-medium">π</span>
                </div>
              </div>

              {/* Memo preview */}
              {isValidAmount && (
                <div className="bg-muted/40 rounded-xl p-3 mb-5 border border-border">
                  <p className="text-xs text-muted-foreground mb-1">Memo</p>
                  <p className="text-sm font-medium">Donation to {churchName}</p>
                </div>
              )}

              {error && (
                <p className="text-xs text-destructive mb-4 text-center">{error}</p>
              )}

              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={handleClose}>
                  Cancel
                </Button>
                <Button
                  className="flex-1 gap-2"
                  disabled={!isValidAmount}
                  onClick={handleDonate}
                >
                  <Coins className="w-4 h-4" />
                  Send {isValidAmount ? `${parsedAmount} π` : "Pi"}
                </Button>
              </div>
            </div>
          )}

          {/* ── Processing step ── */}
          {step === "processing" && (
            <div className="p-8 flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
              </div>
              <DialogHeader>
                <DialogTitle>Opening Pi Wallet...</DialogTitle>
                <DialogDescription className="leading-relaxed">
                  Please confirm the payment of <strong>{parsedAmount} π</strong> in your Pi Wallet app.
                </DialogDescription>
              </DialogHeader>
              <Button variant="ghost" size="sm" onClick={() => setStep("input")} className="gap-1.5 text-muted-foreground">
                <X className="w-3.5 h-3.5" /> Cancel
              </Button>
            </div>
          )}

          {/* ── Success step ── */}
          {step === "success" && (
            <div className="p-8 flex flex-col items-center text-center gap-4">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                <CircleCheck className="w-8 h-8 text-green-600" />
              </div>
              <DialogHeader>
                <DialogTitle>Donation Sent!</DialogTitle>
                <DialogDescription className="leading-relaxed">
                  Thank you for your generous gift of <strong>{parsedAmount} π</strong> to {churchName}.
                </DialogDescription>
              </DialogHeader>
              {txId && (
                <p className="text-xs text-muted-foreground font-mono break-all bg-muted/40 rounded-lg px-3 py-2 border border-border w-full">
                  Tx: {txId}
                </p>
              )}
              <Button className="w-full" onClick={handleClose}>
                Done
              </Button>
            </div>
          )}

          {/* ── Manual fallback step ── */}
          {step === "manual" && (
            <div className="p-5">
              <DialogHeader className="mb-3 text-left">
                <DialogTitle className="text-base">Donate in Pi</DialogTitle>
                <DialogDescription className="text-sm leading-relaxed">
                  Copy the wallet address below and send your donation directly from your Pi Wallet.
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-3 mb-4">
                {/* Amount */}
                <div className="bg-muted/40 rounded-xl p-3 border border-border">
                  <p className="text-xs text-muted-foreground mb-1">Amount</p>
                  <p className="text-base font-bold">{isValidAmount ? `${parsedAmount} π` : "Your chosen amount"}</p>
                </div>

                {/* Wallet Address with big copy button */}
                <div className="bg-muted/40 rounded-xl p-3 border border-border">
                  <p className="text-xs text-muted-foreground mb-1">Wallet Address</p>
                  <p className="text-xs font-mono break-all text-foreground mb-2 leading-relaxed">{walletAddress}</p>
                  <button
                    onClick={copyAddress}
                    className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                      copied
                        ? "bg-green-100 text-green-700 border border-green-200"
                        : "bg-primary text-primary-foreground hover:bg-primary/90"
                    }`}
                  >
                    {copied
                      ? <><Check className="w-4 h-4" /> Copied!</>
                      : <><Copy className="w-4 h-4" /> Copy Address</>
                    }
                  </button>
                </div>

                {/* Memo */}
                <div className="bg-muted/40 rounded-xl p-3 border border-border">
                  <p className="text-xs text-muted-foreground mb-1">Memo</p>
                  <p className="text-sm font-medium">Donation to {churchName}</p>
                </div>
              </div>

              <Button variant="outline" className="w-full mb-3" onClick={handleClose}>
                Done
              </Button>

              <p className="text-xs text-muted-foreground text-center leading-relaxed">
                You're sending this donation manually through your Pi Wallet. We're working on bringing one-tap payments directly in the app soon.
              </p>
            </div>
          )}

        </DialogContent>
      </Dialog>
    </>
  )
}
