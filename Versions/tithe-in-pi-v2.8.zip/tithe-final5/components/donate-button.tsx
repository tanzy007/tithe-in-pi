"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Coins, Copy, Check } from "lucide-react"

declare global {
  interface Window {
    Pi?: {
      createPayment: (payment: object, callbacks: object) => void
      authenticate: (scopes: string[], onIncompletePaymentFound: (payment: object) => void) => Promise<object>
    }
  }
}

export function DonateButton({
  walletAddress,
  churchName,
}: {
  walletAddress: string
  churchName: string
}) {
  const [copied, setCopied] = useState(false)
  const [showManual, setShowManual] = useState(false)
  const [amount, setAmount] = useState("")
  const [paymentStatus, setPaymentStatus] = useState<"idle" | "pending" | "complete" | "cancelled">("idle")

  const handleDonate = () => {
    const donationAmount = parseFloat(amount)
    if (!donationAmount || donationAmount <= 0) {
      alert("Please enter a donation amount")
      return
    }

    if (typeof window !== "undefined" && window.Pi) {
      const payment = {
        amount: donationAmount,
        memo: `Donation to ${churchName}`,
        metadata: {
          churchName,
          walletAddress,
          type: "tithe_donation",
        },
      }

      const callbacks = {
        onReadyForServerApproval: (paymentId: string) => {
          console.log("Payment ready for approval:", paymentId)
          setPaymentStatus("pending")
        },
        onReadyForServerCompletion: (paymentId: string, txid: string) => {
          console.log("Payment complete:", paymentId, txid)
          setPaymentStatus("complete")
        },
        onCancel: (paymentId: string) => {
          console.log("Payment cancelled:", paymentId)
          setPaymentStatus("cancelled")
        },
        onError: (error: Error) => {
          console.error("Payment error:", error)
          setShowManual(true)
        },
      }

      try {
        window.Pi.createPayment(payment, callbacks)
      } catch {
        setShowManual(true)
      }
    } else {
      setShowManual(true)
    }
  }

  const copyAddress = () => {
    navigator.clipboard.writeText(walletAddress).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  const presetAmounts = [1, 3, 5, 10]

  return (
    <div className="bg-card rounded-2xl p-6 border border-border">
      <div className="text-center mb-4">
        <h2 className="font-semibold text-lg mb-1">Support This Ministry</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Donate Pi directly to this church
        </p>
      </div>

      {paymentStatus === "complete" ? (
        <div className="text-center py-4">
          <div className="text-4xl mb-3">🙏</div>
          <p className="font-semibold text-green-600 mb-1">Donation Sent!</p>
          <p className="text-sm text-muted-foreground">Thank you for supporting this ministry.</p>
          <button
            onClick={() => { setPaymentStatus("idle"); setAmount("") }}
            className="text-xs text-primary mt-3 underline"
          >
            Donate again
          </button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-4 gap-2 mb-3">
            {presetAmounts.map((preset) => (
              <button
                key={preset}
                onClick={() => setAmount(preset.toString())}
                className={`py-2 rounded-lg text-sm font-semibold border transition-colors ${
                  amount === preset.toString()
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-muted/40 border-border hover:border-primary/50 text-muted-foreground"
                }`}
              >
                {preset}π
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 mb-4 bg-muted/30 rounded-xl border border-border px-3 py-2">
            <span className="text-muted-foreground text-sm">π</span>
            <input
              type="number"
              min="0.01"
              step="0.01"
              placeholder="Custom amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground/50"
            />
          </div>

          <Button
            onClick={handleDonate}
            className="w-full h-12 text-base gap-2"
            size="lg"
            disabled={!amount || parseFloat(amount) <= 0}
          >
            <Coins className="w-5 h-5" />
            Donate {amount ? `${amount}π` : "in Pi"}
          </Button>

          {paymentStatus === "cancelled" && (
            <p className="text-xs text-muted-foreground text-center mt-2">
              Payment cancelled. Try again anytime.
            </p>
          )}

          {showManual && (
            <div className="mt-4 p-4 bg-muted/40 rounded-xl border border-border">
              <p className="text-sm font-semibold mb-1 text-center">Send Pi directly to this wallet</p>
              <p className="text-xs text-muted-foreground text-center mb-3 leading-relaxed">
                Open your Pi wallet, tap Send, and paste the address below
              </p>
              <div className="flex items-center gap-2 bg-background rounded-lg p-2 border border-border">
                <code className="text-xs flex-1 truncate text-muted-foreground">{walletAddress}</code>
                <button
                  onClick={copyAddress}
                  className="flex-shrink-0 p-1.5 rounded-md hover:bg-muted transition-colors"
                >
                  {copied
                    ? <Check className="w-4 h-4 text-green-500" />
                    : <Copy className="w-4 h-4 text-muted-foreground" />
                  }
                </button>
              </div>
              <p className="text-xs text-muted-foreground text-center mt-2">
                Memo: <span className="font-medium">Donation to {churchName}</span>
              </p>
            </div>
          )}

          {!showManual && (
            <p className="text-xs text-muted-foreground text-center mt-3 leading-relaxed">
              You control the amount. Funds go directly to the church wallet.
            </p>
          )}
        </>
      )}
    </div>
  )
}
