import { createBrowserClient } from "@supabase/ssr"


const SUPABASE_URL = "https://olfuqxvmcbuohdyyuvyh.supabase.co"
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9sZnVxeHZtY2J1b2hkeXl1dnloIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQxOTkxMTQsImV4cCI6MjA3OTc3NTExNH0.GaSoAA02WPBl732kzWTSRb6LQFyXbiRRKmAWX78i-mA"

let supabaseClient: ReturnType<typeof createBrowserClient> | null = null

export function getSupabase() {
  if (supabaseClient) {
    return supabaseClient
  }

  supabaseClient = createBrowserClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY,
  )

  return supabaseClient
}

export type Church = {
  id: string
  name: string
  denomination: string | null
  city: string
  country: string
  website: string | null
  email: string
  description: string | null
  wallet_address: string | null
  kyb_status: boolean
  onboarding_step: number
  onboarding_completed: boolean
  created_at: string
}
