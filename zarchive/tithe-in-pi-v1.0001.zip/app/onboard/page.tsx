"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Navigation } from "@/components/navigation"
import { getSupabase } from "@/lib/supabase"
import { ArrowLeft, ExternalLink, Check } from "lucide-react"
import Link from "next/link"

export default function OnboardPage() {
  const searchParams = useSearchParams()
  const churchIdFromUrl = searchParams.get("id")

  const [churches, setChurches] = useState<
    Array<{
      id: string
      name: string
      onboarding_step: number
      onboarding_completed: boolean
      wallet_address: string | null
    }>
  >([])
  const [selectedChurch, setSelectedChurch] = useState("")
  const [currentStep, setCurrentStep] = useState(0)
  const [walletAddress, setWalletAddress] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState("")

  useEffect(() => {
    loadChurches()
  }, [])

  const loadChurches = async () => {
    const supabase = getSupabase()
    const { data } = await supabase
      .from("churches")
      .select("id, name, onboarding_step, onboarding_completed, wallet_address")
      .order("created_at", { ascending: false })

    if (data) {
      setChurches(data)

      // Select church from URL or default to first
      const churchToSelect = churchIdFromUrl || (data.length > 0 ? data[0].id : "")
      if (churchToSelect) {
        const church = data.find((c) => c.id === churchToSelect) || data[0]
        setSelectedChurch(church.id)
        setCurrentStep(church.onboarding_step || 0)
        setWalletAddress(church.wallet_address || "")
      }
    }
  }

  const handleChurchChange = (churchId: string) => {
    setSelectedChurch(churchId)
    const church = churches.find((c) => c.id === churchId)
    if (church) {
      setCurrentStep(church.onboarding_step || 0)
      setWalletAddress(church.wallet_address || "")
    }
  }

  const updateStep = async (step: number, additionalData?: Record<string, any>) => {
    if (!selectedChurch) return
    setLoading(true)
    try {
      const supabase = getSupabase()
      const updateData = { onboarding_step: step, ...additionalData }
      await supabase.from("churches").update(updateData).eq("id", selectedChurch)
      setCurrentStep(step)
      setSuccess("Progress saved!")
      setTimeout(() => setSuccess(""), 2000)
      loadChurches()
    } finally {
      setLoading(false)
    }
  }

  const completeOnboarding = async () => {
    if (!selectedChurch) return
    setLoading(true)
    try {
      const supabase = getSupabase()
      await supabase
        .from("churches")
        .update({ onboarding_step: 4, onboarding_completed: true })
        .eq("id", selectedChurch)
      setCurrentStep(4)
      setSuccess("Onboarding complete! Your church is now Pi-ready!")
      setTimeout(() => setSuccess(""), 3000)
      loadChurches()
    } finally {
      setLoading(false)
    }
  }

  const handleSaveWallet = async () => {
    if (!walletAddress) return
    await updateStep(3, { wallet_address: walletAddress })
  }

  const selectedChurchData = churches.find((c) => c.id === selectedChurch)
  const isCompleted = selectedChurchData?.onboarding_completed

  return (
    <>
      <div className="min-h-screen bg-background pb-20">
        <main className="container mx-auto px-4 py-6 max-w-lg">
          <div className="mb-6">
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
            <h1 className="text-2xl font-bold mb-2">Church Onboarding</h1>
            <p className="text-muted-foreground text-sm">Complete 4 steps to become Pi-ready</p>
          </div>

          {churches.length > 0 && (
            <div className="mb-6">
              <Label htmlFor="church-select">Select Your Church</Label>
              <select
                id="church-select"
                value={selectedChurch}
                onChange={(e) => handleChurchChange(e.target.value)}
                className="w-full mt-1.5 h-10 rounded-lg border border-input bg-background px-3 py-2 text-sm"
              >
                {churches.map((church) => (
                  <option key={church.id} value={church.id}>
                    {church.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          {churches.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No churches registered yet</p>
              <Link href="/register">
                <Button>Register Your Church</Button>
              </Link>
            </div>
          )}

          {churches.length > 0 && (
            <>
              {/* Progress Bar */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Progress</span>
                  <span className="text-sm text-muted-foreground">Step {Math.min(currentStep + 1, 4)} of 4</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-300"
                    style={{ width: `${(Math.min(currentStep + 1, 4) / 4) * 100}%` }}
                  />
                </div>
              </div>

              {isCompleted && (
                <div className="bg-accent/10 border border-accent/20 rounded-xl p-4 mb-6 text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/20 mb-2">
                    <Check className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="font-semibold mb-1">Onboarding Complete!</h3>
                  <p className="text-sm text-muted-foreground">
                    Your church is now Pi-ready and visible in the directory
                  </p>
                </div>
              )}

              <div className="space-y-4">
                {/* Step 1: KYB Submission */}
                <div
                  className={`rounded-xl p-5 border transition-all ${
                    currentStep === 0 && !isCompleted ? "bg-card border-primary shadow-sm" : "bg-card/50 border-border"
                  }`}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-sm ${
                        currentStep > 0 || isCompleted
                          ? "bg-accent text-white"
                          : currentStep === 0
                            ? "bg-primary text-white"
                            : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {currentStep > 0 || isCompleted ? <Check className="w-4 h-4" /> : "1"}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">Submit KYB Application</h3>
                      <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                        Complete Pi Core Team's Know Your Business form
                      </p>
                      <a
                        href="https://minepi.com/kyb-business-pi/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 text-sm text-primary hover:underline mb-3"
                      >
                        Open KYB Form
                        <ExternalLink className="w-4 h-4" />
                      </a>
                      {currentStep === 0 && !isCompleted && (
                        <Button onClick={() => updateStep(1)} disabled={loading} className="w-full mt-2" size="sm">
                          Mark Step 1 Complete
                        </Button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Step 2: Create Pi Wallet */}
                <div
                  className={`rounded-xl p-5 border transition-all ${
                    currentStep === 1 && !isCompleted ? "bg-card border-primary shadow-sm" : "bg-card/50 border-border"
                  }`}
                >
                  <div className="flex items-start gap-3 mb-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-sm ${
                        currentStep > 1 || isCompleted
                          ? "bg-accent text-white"
                          : currentStep === 1
                            ? "bg-primary text-white"
                            : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {currentStep > 1 || isCompleted ? <Check className="w-4 h-4" /> : "2"}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">Create Pi Wallet</h3>
                      <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                        Set up your official Pi Wallet to receive donations
                      </p>
                      <a
                        href="https://minepi.com/wallet"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 text-sm text-primary hover:underline mb-3"
                      >
                        Pi Wallet Setup Guide
                        <ExternalLink className="w-4 h-4" />
                      </a>
                      {currentStep === 1 && !isCompleted && (
                        <Button onClick={() => updateStep(2)} disabled={loading} className="w-full mt-2" size="sm">
                          Mark Step 2 Complete
                        </Button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Step 3: Add Wallet Address */}
                <div
                  className={`rounded-xl p-5 border transition-all ${
                    currentStep === 2 && !isCompleted ? "bg-card border-primary shadow-sm" : "bg-card/50 border-border"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-sm ${
                        currentStep > 2 || isCompleted
                          ? "bg-accent text-white"
                          : currentStep === 2
                            ? "bg-primary text-white"
                            : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {currentStep > 2 || isCompleted ? <Check className="w-4 h-4" /> : "3"}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">Add Wallet Address</h3>
                      <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                        Enter your Pi wallet address for receiving donations
                      </p>
                      {currentStep >= 2 && !isCompleted && (
                        <div className="space-y-3">
                          <Input
                            value={walletAddress}
                            onChange={(e) => setWalletAddress(e.target.value)}
                            placeholder="Enter your Pi wallet address"
                            className="font-mono text-sm"
                          />
                          <Button
                            onClick={handleSaveWallet}
                            disabled={loading || !walletAddress}
                            className="w-full"
                            size="sm"
                          >
                            Save & Continue to Step 4
                          </Button>
                        </div>
                      )}
                      {currentStep > 2 && walletAddress && (
                        <div className="text-sm text-muted-foreground font-mono truncate">{walletAddress}</div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Step 4: Team Vetting */}
                <div
                  className={`rounded-xl p-5 border transition-all ${
                    currentStep === 3 && !isCompleted ? "bg-card border-primary shadow-sm" : "bg-card/50 border-border"
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 font-semibold text-sm ${
                        isCompleted
                          ? "bg-accent text-white"
                          : currentStep === 3
                            ? "bg-primary text-white"
                            : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {isCompleted ? <Check className="w-4 h-4" /> : "4"}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold mb-1">Team Vetting Complete</h3>
                      <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
                        Mark when your church has been vetted and approved
                      </p>
                      {currentStep === 3 && !isCompleted && (
                        <Button onClick={completeOnboarding} disabled={loading} className="w-full" size="sm">
                          Complete Onboarding
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {success && (
                <div className="mt-4 p-3 bg-accent/10 border border-accent/20 rounded-lg text-sm text-accent text-center">
                  {success}
                </div>
              )}
            </>
          )}
        </main>
      </div>
      <Navigation />
    </>
  )
}
