import { getSupabase } from "@/lib/supabase"
import { Navigation } from "@/components/navigation"
import { DonateButton } from "@/components/donate-button"
import { ArrowLeft, MapPin, Globe, Mail, CheckCircle2, Building2 } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"

export default async function ChurchProfilePage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = getSupabase()

  const { data: church } = await supabase.from("churches").select("*").eq("id", id).single()

  if (!church) {
    notFound()
  }

  const isPiReady = church.onboarding_completed && church.wallet_address

  return (
    <>
      <div className="min-h-screen bg-background pb-20">
        <main className="container mx-auto px-4 py-6 max-w-lg">
          <div className="mb-6">
            <Link
              href="/directory"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Directory
            </Link>
          </div>

          {/* Church Header */}
          <div className="bg-card rounded-2xl p-6 border border-border mb-4">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-16 h-16 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Building2 className="w-8 h-8 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h1 className="text-2xl font-bold mb-2 text-balance">{church.name}</h1>
                {isPiReady && (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-accent/10 text-accent rounded-full text-sm font-medium">
                    <CheckCircle2 className="w-4 h-4" />
                    Pi-Ready
                  </div>
                )}
              </div>
            </div>

            {church.description && <p className="text-muted-foreground leading-relaxed mb-4">{church.description}</p>}

            <div className="space-y-2.5">
              <div className="flex items-center gap-2.5 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                <span>
                  {church.city}, {church.country}
                </span>
              </div>

              {church.denomination && (
                <div className="flex items-center gap-2.5 text-sm">
                  <Building2 className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <span>{church.denomination}</span>
                </div>
              )}

              {church.email && (
                <div className="flex items-center gap-2.5 text-sm">
                  <Mail className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <a href={`mailto:${church.email}`} className="text-primary hover:underline truncate">
                    {church.email}
                  </a>
                </div>
              )}

              {church.website && (
                <div className="flex items-center gap-2.5 text-sm">
                  <Globe className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <a
                    href={church.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline truncate"
                  >
                    {church.website}
                  </a>
                </div>
              )}
            </div>
          </div>

          {/* Donation Section */}
          {isPiReady ? (
            <DonateButton walletAddress={church.wallet_address!} churchName={church.name} />
          ) : (
            <div className="bg-muted/50 rounded-xl p-6 text-center">
              <p className="text-sm text-muted-foreground leading-relaxed">
                This church is still completing their Pi onboarding process. Check back soon to support them with Pi
                donations.
              </p>
            </div>
          )}
        </main>
      </div>
      <Navigation />
    </>
  )
}
