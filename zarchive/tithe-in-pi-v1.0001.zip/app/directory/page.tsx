"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Navigation } from "@/components/navigation"
import { getSupabase, type Church } from "@/lib/supabase"
import { Search, MapPin, ChurchIcon, CheckCircle2 } from "lucide-react"

export default function DirectoryPage() {
  const [churches, setChurches] = useState<Church[]>([])
  const [filteredChurches, setFilteredChurches] = useState<Church[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [cityFilter, setCityFilter] = useState("")
  const [denominationFilter, setDenominationFilter] = useState("")
  const [piReadyOnly, setPiReadyOnly] = useState(false)
  const [cities, setCities] = useState<string[]>([])
  const [denominations, setDenominations] = useState<string[]>([])

  useEffect(() => {
    loadChurches()
  }, [])

  useEffect(() => {
    filterChurches()
  }, [searchTerm, cityFilter, denominationFilter, piReadyOnly, churches])

  const loadChurches = async () => {
    const supabase = getSupabase()
    const { data } = await supabase.from("churches").select("*").order("created_at", { ascending: false })

    if (data) {
      setChurches(data)
      setFilteredChurches(data)

      // Extract unique cities and denominations
      const uniqueCities = [...new Set(data.map((c) => c.city).filter(Boolean))]
      const uniqueDenominations = [...new Set(data.map((c) => c.denomination).filter(Boolean))]
      setCities(uniqueCities.sort())
      setDenominations(uniqueDenominations.sort())
    }
  }

  const filterChurches = () => {
    let filtered = churches

    if (searchTerm) {
      filtered = filtered.filter(
        (church) =>
          church.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          church.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
          church.country.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (cityFilter) {
      filtered = filtered.filter((church) => church.city === cityFilter)
    }

    if (denominationFilter) {
      filtered = filtered.filter((church) => church.denomination === denominationFilter)
    }

    if (piReadyOnly) {
      filtered = filtered.filter((church) => church.onboarding_completed && church.wallet_address)
    }

    setFilteredChurches(filtered)
  }

  const isPiReady = (church: Church) => {
    return church.onboarding_completed && church.wallet_address
  }

  return (
    <>
      <div className="min-h-screen bg-background pb-20">
        <main className="container mx-auto px-4 py-6 max-w-lg">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-2">Church Directory</h1>
            <p className="text-muted-foreground text-sm">Discover Pi-accepting ministries</p>
          </div>

          {/* Search */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search churches..."
                className="pl-10"
              />
            </div>
          </div>

          {/* Filters */}
          <div className="space-y-3 mb-6">
            <div className="grid grid-cols-2 gap-3">
              <select
                value={cityFilter}
                onChange={(e) => setCityFilter(e.target.value)}
                className="h-10 rounded-lg border border-input bg-background px-3 text-sm"
              >
                <option value="">All Cities</option>
                {cities.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
              <select
                value={denominationFilter}
                onChange={(e) => setDenominationFilter(e.target.value)}
                className="h-10 rounded-lg border border-input bg-background px-3 text-sm"
              >
                <option value="">All Denominations</option>
                {denominations.map((denom) => (
                  <option key={denom} value={denom}>
                    {denom}
                  </option>
                ))}
              </select>
            </div>
            <Button
              variant={piReadyOnly ? "default" : "outline"}
              onClick={() => setPiReadyOnly(!piReadyOnly)}
              className="w-full"
              size="sm"
            >
              {piReadyOnly ? "Showing Pi-Ready Only" : "Show All Churches"}
            </Button>
          </div>

          {/* Results Count */}
          <div className="text-sm text-muted-foreground mb-4">
            {filteredChurches.length} {filteredChurches.length === 1 ? "church" : "churches"} found
          </div>

          {/* Church List */}
          <div className="space-y-3">
            {filteredChurches.map((church) => (
              <Link
                key={church.id}
                href={`/church/${church.id}`}
                className="block bg-card rounded-xl p-4 border border-border hover:border-primary/50 transition-colors"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <ChurchIcon className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-base mb-1 truncate">{church.name}</h3>
                      <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-1">
                        <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                        <span className="truncate">
                          {church.city}, {church.country}
                        </span>
                      </div>
                      {church.denomination && (
                        <div className="text-xs text-muted-foreground">{church.denomination}</div>
                      )}
                    </div>
                  </div>
                  {isPiReady(church) && <CheckCircle2 className="w-5 h-5 text-accent flex-shrink-0" />}
                </div>
                {church.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2 mt-2">{church.description}</p>
                )}
              </Link>
            ))}

            {filteredChurches.length === 0 && (
              <div className="text-center py-12">
                <ChurchIcon className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-muted-foreground">No churches found</p>
                <p className="text-sm text-muted-foreground mt-1">Try adjusting your filters</p>
              </div>
            )}
          </div>
        </main>
      </div>
      <Navigation />
    </>
  )
}
