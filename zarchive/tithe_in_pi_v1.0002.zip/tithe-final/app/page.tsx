import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Navigation } from "@/components/navigation"
import { Coins, Church, Heart } from "lucide-react"

export default function HomePage() {
  return (
    <>
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary/20 pb-20">
        <main className="container mx-auto px-4 py-8 max-w-lg">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <Coins className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2 text-balance">Tithe in Pi</h1>
            <p className="text-muted-foreground text-balance">
              Supporting ministries through Pi cryptocurrency donations
            </p>
          </div>

          {/* Hero Card */}
          <div className="bg-card rounded-2xl p-6 shadow-sm border border-border mb-6">
            <div className="flex items-start gap-3 mb-4">
              <Church className="w-6 h-6 text-accent mt-1 flex-shrink-0" />
              <div>
                <h2 className="font-semibold text-lg mb-1">For Churches</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Register your church and become Pi-ready to receive digital donations from your community.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Heart className="w-6 h-6 text-accent mt-1 flex-shrink-0" />
              <div>
                <h2 className="font-semibold text-lg mb-1">For Donors</h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Discover Pi-accepting ministries and support them securely through your Pi Wallet.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-3">
            <Link href="/register" className="block">
              <Button className="w-full h-14 text-base" size="lg">
                Register Your Church
              </Button>
            </Link>
            <Link href="/directory" className="block">
              <Button variant="outline" className="w-full h-14 text-base bg-transparent" size="lg">
                Browse Directory
              </Button>
            </Link>
            <Link href="/onboard" className="block">
              <Button variant="secondary" className="w-full h-14 text-base" size="lg">
                Complete Onboarding
              </Button>
            </Link>
          </div>

          {/* Info Section */}
          <div className="mt-8 p-4 bg-muted/50 rounded-xl">
            <p className="text-sm text-muted-foreground text-center leading-relaxed">
              All donations are processed securely through the Pi Network wallet. No payment information is stored or
              handled by this platform.
            </p>
          </div>
        </main>
      </div>
      <Navigation />
    </>
  )
}
