"use client"

import { Button } from "@/components/ui/button"
import { Coins } from "lucide-react"

export function DonateButton({
  walletAddress,
  churchName,
}: {
  walletAddress: string
  churchName: string
}) {
  const handleDonate = () => {
    // Open Pi wallet with pre-filled address
    // Format: pi://[wallet_address]?amount=&memo=
    const piUrl = `pi://${walletAddress}?memo=${encodeURIComponent(`Donation to ${churchName}`)}`
    window.location.href = piUrl
  }

  return (
    <div className="bg-card rounded-2xl p-6 border border-border">
      <div className="text-center mb-4">
        <h2 className="font-semibold text-lg mb-2">Support This Ministry</h2>
        <p className="text-sm text-muted-foreground leading-relaxed">Donate securely through your Pi Wallet</p>
      </div>
      <Button onClick={handleDonate} className="w-full h-14 text-base gap-2" size="lg">
        <Coins className="w-5 h-5" />
        Donate in Pi
      </Button>
      <p className="text-xs text-muted-foreground text-center mt-3 leading-relaxed">
        This will open your Pi Wallet app with the church's wallet address pre-filled. You control the donation amount.
      </p>
    </div>
  )
}
